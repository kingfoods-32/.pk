/* Storage upgrade: the "kfo" data (prices, settings, photos) now lives in IndexedDB
   (hundreds of MB) instead of localStorage (~5 MB). Everything else works as before. */
(function(){
var KEY="kfo",FLAG="kfo__del",LS=window.localStorage,P=Storage.prototype;
var nGet=P.getItem,nSet=P.setItem,nRem=P.removeItem;
var cache=null,ok=false,db=null;
function tx(mode,fn){return new Promise(function(res,rej){var t=db.transaction("kv",mode),s=t.objectStore("kv"),r=fn(s);t.oncomplete=function(){res(r&&r.result)};t.onerror=t.onabort=function(){rej(t.error)}})}
function open(){return new Promise(function(res,rej){if(!window.indexedDB)return rej();var r=indexedDB.open("kingfoods",1);r.onupgradeneeded=function(){r.result.createObjectStore("kv")};r.onsuccess=function(){db=r.result;res()};r.onerror=r.onblocked=function(){rej(r.error)}})}
var load=open().then(function(){
  if(nGet.call(LS,FLAG)){nRem.call(LS,FLAG);return tx("readwrite",function(s){return s.delete(KEY)}).then(function(){nRem.call(LS,KEY);return null})}
  return tx("readonly",function(s){return s.get(KEY)}).then(function(v){
    if(v==null){var old=nGet.call(LS,KEY);
      if(old!=null)return tx("readwrite",function(s){return s.put(old,KEY)}).then(function(){nRem.call(LS,KEY);return old});
    }
    return v;
  });
}).then(function(v){cache=v==null?null:v;ok=true;try{navigator.storage&&navigator.storage.persist&&navigator.storage.persist()}catch(e){}}).catch(function(){ok=false});
window.__kfReady=Promise.race([load,new Promise(function(r){setTimeout(r,4000)})]);
P.getItem=function(k){return(k===KEY&&ok)?cache:nGet.call(this,k)};
P.setItem=function(k,v){
  if(k===KEY&&ok){v=String(v);cache=v;tx("readwrite",function(s){return s.put(v,KEY)}).catch(function(){alert("Storage is full. Remove some photos or use smaller ones.")});return}
  return nSet.call(this,k,v)};
P.removeItem=function(k){
  if(k===KEY&&ok){cache=null;try{nSet.call(LS,FLAG,"1")}catch(e){}tx("readwrite",function(s){return s.delete(KEY)}).then(function(){nRem.call(LS,FLAG)}).catch(function(){});return}
  return nRem.call(this,k)};
})();
