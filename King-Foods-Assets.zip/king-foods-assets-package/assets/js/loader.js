(window.__kfReady||Promise.resolve()).then(function(){
  var script=document.createElement('script');
  script.src='assets/js/main.js';
  document.body.appendChild(script);
});
