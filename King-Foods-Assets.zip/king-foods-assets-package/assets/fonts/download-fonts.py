# Optional font downloader (requires Python 3 and internet access)
from pathlib import Path
from urllib.request import Request, urlopen
import re

folder = Path(__file__).resolve().parent
css_url = "https://fonts.googleapis.com/css2?family=Fraunces:wght@600;800&family=Plus+Jakarta+Sans:wght@400;500;700&display=swap"
request = Request(css_url, headers={"User-Agent": "Mozilla/5.0"})
css = urlopen(request, timeout=30).read().decode("utf-8")
urls = list(dict.fromkeys(re.findall(r"url\\((https://[^)]+\\.woff2)\\)", css)))
for index, url in enumerate(urls, 1):
    data = urlopen(Request(url, headers={"User-Agent": "Mozilla/5.0"}), timeout=30).read()
    target = folder / f"font-{index:02d}.woff2"
    target.write_bytes(data)
    print(f"Saved {target.name}")
print(f"Downloaded {len(urls)} WOFF2 font files. To use offline, add @font-face rules in ../css/style.css.")
