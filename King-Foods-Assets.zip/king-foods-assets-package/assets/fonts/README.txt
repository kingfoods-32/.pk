Fonts used by this website
==========================
The original design uses Fraunces (headings/logo) and Plus Jakarta Sans (body text).

Online font stylesheet:
https://fonts.googleapis.com/css2?family=Fraunces:wght@600;800&family=Plus+Jakarta+Sans:wght@400;500;700&display=swap

To download font files for offline use, open the stylesheet URL in a browser, then open the font URLs shown in its CSS and save the WOFF2 files into this folder. Update ../css/style.css to use @font-face declarations pointing to those local WOFF2 files. Until then, the page uses Google Fonts online and system fallback fonts offline.
