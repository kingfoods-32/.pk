KING FOODS website assets
- css/style.css: extracted original page styles
- js/storage.js: existing browser storage upgrade
- js/main.js: original website logic
- js/loader.js: loads main.js after storage initialization
- logo/king-foods-logo.svg: editable vector logo
- fonts/: font download instructions
- image/: folder for separately managed images

Keep index.html beside the assets folder. The existing page's embedded banner/menu content is preserved.
